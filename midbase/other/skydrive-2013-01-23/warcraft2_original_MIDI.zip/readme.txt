     Folks,

        Attached are the OFFICIAL Warcraft 2 MIDI files in General MIDI
     format.  I saw that there were only two of the songs in the .zip file
     on the "Game Music Homepage", and just wanted to make sure you had
     access to them all, and that the ones you had were the original,
     unmodified ones, straight from the source; the ones on the Game Music
     page sounded kind of funny, and parts seemed to be missing.  I got
     your names from either the contact info on this homepage, or on the
     "wish list" for MIDI files.
        Enjoy the songs as much as you like, and feel free to distribute
     them with this message attached, but please remember that the MIDI
     files remain copywritten properties of Blizzard Entertainment and are
     not to be sold, modified, reproduced, used for other purposes, etc.
     As far as I'm concerned, the more people that get their hands on them,
     the better; maybe they'll want to go out and buy the game!
        Check out Diablo; Matt Uelmen at Blizzard North did a great job on
     the music, and I helped out with voices and sound effects.  Sorry, no
     MIDI files though - it's all digital audio.  Also keep an eye out for
     Starcraft coming this spring/summer!

     These MIDI files are best listened to on Roland or Yamaha General MIDI
     compatible sound cards.

     Regards,

     Glenn Stafford, director of audio
     Blizzard Entertainment
     gstafford@blizzard.com
     http:/www.blizzard.com
